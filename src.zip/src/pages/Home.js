// src/pages/Home.js
import React from 'react';

export default function Home() {
  return (
    <main>
    <section>
      <h2>Home</h2>
      <p>Welcome to the about page. Here you can learn more about me.</p>
    </section>
    </main>
  );
}
