// src/pages/Projects.js
import React from 'react';

export default function Projects() {
  return (
    <section>
      <h2>Projects</h2>
      <p>Check out some of my projects.</p>
    </section>
  );
}
