// src/pages/Skills.js
import React from 'react';

export default function Skills() {
  return (
    <section>
      <h2>Skills</h2>
      <p>These are my skills.</p>
    </section>
  );
}
